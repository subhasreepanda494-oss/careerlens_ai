"""CareerLens AI external FastAPI service."""
