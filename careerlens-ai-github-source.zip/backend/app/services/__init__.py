"""Business workflows for the CareerLens FastAPI service."""
