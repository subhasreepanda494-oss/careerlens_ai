from datetime import UTC, datetime

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.security import TokenValidationError, create_access_token, create_refresh_token, decode_token, hash_password, hash_refresh_token, verify_password
from app.models import RefreshToken, User


class DuplicateEmailError(Exception):
    pass


class InvalidCredentialsError(Exception):
    pass


class RefreshTokenError(Exception):
    pass


def normalize_email(email: str) -> str:
    return email.strip().lower()


def issue_tokens(db: Session, user: User) -> tuple[str, str, datetime]:
    access_token, _, access_expires_at = create_access_token(user.id)
    refresh_token, jwt_id, refresh_expires_at = create_refresh_token(user.id)
    db.add(RefreshToken(user_id=user.id, jwt_id=jwt_id, token_hash=hash_refresh_token(refresh_token), expires_at=refresh_expires_at))
    db.commit()
    return access_token, refresh_token, access_expires_at


def signup(db: Session, full_name: str, email: str, password: str) -> tuple[User, str, str, datetime]:
    normalized_email = normalize_email(email)
    if db.scalar(select(User).where(User.email == normalized_email)):
        raise DuplicateEmailError()
    user = User(full_name=full_name.strip(), email=normalized_email, password_hash=hash_password(password))
    db.add(user)
    db.commit()
    db.refresh(user)
    access_token, refresh_token, expires_at = issue_tokens(db, user)
    return user, access_token, refresh_token, expires_at


def login(db: Session, email: str, password: str) -> tuple[User, str, str, datetime]:
    user = db.scalar(select(User).where(User.email == normalize_email(email)))
    if not user or not verify_password(password, user.password_hash):
        raise InvalidCredentialsError()
    access_token, refresh_token, expires_at = issue_tokens(db, user)
    return user, access_token, refresh_token, expires_at


def refresh(db: Session, raw_refresh_token: str) -> tuple[str, str, datetime]:
    try:
        claims = decode_token(raw_refresh_token, "refresh")
    except TokenValidationError as exc:
        raise RefreshTokenError() from exc
    token_row = db.scalar(select(RefreshToken).where(RefreshToken.jwt_id == claims["jti"]))
    now = datetime.now(UTC)
    expires_at = token_row.expires_at.replace(tzinfo=UTC) if token_row and token_row.expires_at.tzinfo is None else token_row.expires_at if token_row else None
    if not token_row or token_row.token_hash != hash_refresh_token(raw_refresh_token) or token_row.revoked_at or not expires_at or expires_at <= now:
        raise RefreshTokenError()
    user = db.get(User, claims["sub"])
    if not user:
        raise RefreshTokenError()
    token_row.revoked_at = now
    access_token, refresh_token, expires_at = issue_tokens(db, user)
    replacement = db.scalar(select(RefreshToken).where(RefreshToken.token_hash == hash_refresh_token(refresh_token)))
    if replacement:
        token_row.replaced_by_id = replacement.id
        db.commit()
    return access_token, refresh_token, expires_at


def revoke(db: Session, raw_refresh_token: str) -> None:
    try:
        claims = decode_token(raw_refresh_token, "refresh")
    except TokenValidationError as exc:
        raise RefreshTokenError() from exc
    token_row = db.scalar(select(RefreshToken).where(RefreshToken.jwt_id == claims["jti"]))
    if not token_row or token_row.token_hash != hash_refresh_token(raw_refresh_token):
        raise RefreshTokenError()
    if not token_row.revoked_at:
        token_row.revoked_at = datetime.now(UTC)
        db.commit()


def current_user(db: Session, raw_access_token: str) -> User:
    try:
        claims = decode_token(raw_access_token, "access")
    except TokenValidationError as exc:
        raise InvalidCredentialsError() from exc
    user = db.get(User, claims["sub"])
    if not user:
        raise InvalidCredentialsError()
    return user
