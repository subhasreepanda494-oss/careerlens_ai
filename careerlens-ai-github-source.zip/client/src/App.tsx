/**
 * CareerLens AI — Evidence Ledger design system.
 * This application shell preserves a calm, editorial workspace: Lens Blue marks decisive actions,
 * Indigo Ink creates hierarchy, and Aubergine Violet identifies AI-generated recommendations.
 */
import { Toaster } from "@/components/ui/sonner";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" switchable>
        <Home />
        <Toaster richColors position="top-right" />
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
