import { describe, expect, it } from "vitest";

describe("deferred auth endpoint configuration", () => {
  it("keeps the external auth endpoint disabled when no public URL is configured", async () => {
    const baseUrl = import.meta.env.VITE_AUTH_API_BASE_URL as string | undefined;
    if (!baseUrl || !/^https:\/\//i.test(baseUrl)) {
      expect(baseUrl ?? "").not.toMatch(/^https:\/\//i);
      return;
    }

    const response = await fetch(`${baseUrl.replace(/\/$/, "")}/health`);
    expect(response.ok).toBe(true);
  });
});
