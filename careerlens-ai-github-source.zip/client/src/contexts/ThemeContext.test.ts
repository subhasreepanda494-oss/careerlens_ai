import { describe, expect, it } from "vitest";
import { resolveTheme } from "./ThemeContext";

describe("resolveTheme", () => {
  it("honors valid saved theme values", () => {
    expect(resolveTheme("dark", "light")).toBe("dark");
    expect(resolveTheme("light", "dark")).toBe("light");
  });

  it("falls back safely for missing or invalid values", () => {
    expect(resolveTheme(null, "light")).toBe("light");
    expect(resolveTheme("system", "dark")).toBe("dark");
  });
});
