import React from "react";
import { act, create } from "react-test-renderer";
import { describe, expect, it, vi } from "vitest";
import { ThemeProvider, useTheme } from "./ThemeContext";

function ThemeProbe() {
  const { theme, toggleTheme } = useTheme();
  return <button onClick={toggleTheme}>{theme}</button>;
}

describe("ThemeProvider interaction", () => {
  it("toggles the root class and persists the selected theme", async () => {
    const classNames = new Set<string>();
    const storage = new Map<string, string>();
    vi.stubGlobal("localStorage", {
      getItem: (key: string) => storage.get(key) ?? null,
      setItem: (key: string, value: string) => storage.set(key, value),
    });
    vi.stubGlobal("window", { location: { search: "" } });
    vi.stubGlobal("document", { documentElement: { classList: {
      add: (name: string) => classNames.add(name),
      remove: (name: string) => classNames.delete(name),
    } } });

    let renderer: ReturnType<typeof create>;
    await act(async () => {
      renderer = create(<ThemeProvider defaultTheme="light" switchable><ThemeProbe /></ThemeProvider>);
    });
    expect(renderer!.root.findByType("button").children).toEqual(["light"]);
    expect(classNames.has("dark")).toBe(false);

    await act(async () => {
      renderer!.root.findByType("button").props.onClick();
    });
    expect(renderer!.root.findByType("button").children).toEqual(["dark"]);
    expect(classNames.has("dark")).toBe(true);
    expect(storage.get("theme")).toBe("dark");
  });
});
