import { describe, expect, it } from "vitest";

function validateSignup(fullName: string, email: string, password: string, confirmPassword: string) {
  if (fullName.trim().length < 2) return "Enter your full name.";
  if (!/^\S+@\S+\.\S+$/.test(email)) return "Enter a valid email address.";
  if (password.length < 12) return "Use at least 12 characters for your password.";
  if (password !== confirmPassword) return "Passwords do not match.";
  return null;
}

describe("auth form validation", () => {
  it("rejects incomplete or mismatched signup input before an API request", () => {
    expect(validateSignup("A", "not-an-email", "short", "different")).toBe("Enter your full name.");
    expect(validateSignup("Aditi Sharma", "aditi@example.com", "CareerLens2026", "different")).toBe("Passwords do not match.");
  });
  it("accepts a valid signup input", () => {
    expect(validateSignup("Aditi Sharma", "aditi@example.com", "CareerLens2026", "CareerLens2026")).toBeNull();
  });
});
