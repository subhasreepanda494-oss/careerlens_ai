import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";

export type AuthUser = { id: string; full_name: string; email: string; created_at: string };
type TokenBundle = { access_token: string; refresh_token: string; access_expires_at: string; token_type: "bearer" };
type StoredSession = TokenBundle & { remember: boolean };
type Credentials = { email: string; password: string; remember?: boolean };
type SignupCredentials = Credentials & { fullName: string; confirmPassword: string };
type AuthContextValue = { user: AuthUser | null; loading: boolean; isAuthenticated: boolean; login: (credentials: Credentials) => Promise<void>; signup: (credentials: SignupCredentials) => Promise<void>; logout: () => Promise<void>; refreshSession: () => Promise<boolean>; forgotPassword: (email: string) => Promise<string> };

const AuthContext = createContext<AuthContextValue | null>(null);
const SESSION_KEY = "careerlens.auth.session";
const API_BASE_URL = (import.meta.env.VITE_AUTH_API_BASE_URL ?? "").replace(/\/$/, "");

function apiUnavailable() { return new Error("Authentication is not configured. Add VITE_AUTH_API_BASE_URL after deploying the FastAPI service."); }
function getStoredSession(): StoredSession | null { for (const storage of [sessionStorage, localStorage]) { try { const value = storage.getItem(SESSION_KEY); if (value) return JSON.parse(value) as StoredSession; } catch { /* Ignore malformed client storage. */ } } return null; }
function clearStoredSession() { sessionStorage.removeItem(SESSION_KEY); localStorage.removeItem(SESSION_KEY); }
function storeSession(session: StoredSession) { clearStoredSession(); (session.remember ? localStorage : sessionStorage).setItem(SESSION_KEY, JSON.stringify(session)); }

async function request<T>(path: string, options: RequestInit = {}, accessToken?: string): Promise<T> {
  if (!API_BASE_URL) throw apiUnavailable();
  const response = await fetch(`${API_BASE_URL}${path}`, { ...options, headers: { "Content-Type": "application/json", ...(accessToken ? { Authorization: `Bearer ${accessToken}` } : {}), ...(options.headers ?? {}) } });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(typeof body.detail === "string" ? body.detail : "Authentication request failed. Please try again.");
  return body as T;
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const refreshInFlight = useRef<Promise<boolean> | null>(null);
  const refreshSession = useCallback(async (): Promise<boolean> => {
    if (refreshInFlight.current) return refreshInFlight.current;
    const operation = (async () => { const existing = getStoredSession(); if (!existing) { setUser(null); return false; } try { const tokens = await request<TokenBundle>("/api/v1/auth/refresh", { method: "POST", body: JSON.stringify({ refresh_token: existing.refresh_token }) }); const session = { ...tokens, remember: existing.remember }; storeSession(session); setUser(await request<AuthUser>("/api/v1/auth/me", {}, session.access_token)); return true; } catch { clearStoredSession(); setUser(null); return false; } finally { refreshInFlight.current = null; } })();
    refreshInFlight.current = operation;
    return operation;
  }, []);
  useEffect(() => { refreshSession().finally(() => setLoading(false)); }, [refreshSession]);
  const completeLogin = useCallback(async (response: TokenBundle & { user: AuthUser }, remember: boolean) => { storeSession({ access_token: response.access_token, refresh_token: response.refresh_token, access_expires_at: response.access_expires_at, token_type: response.token_type, remember }); setUser(response.user); }, []);
  const login = useCallback(async ({ email, password, remember = false }: Credentials) => { await completeLogin(await request<TokenBundle & { user: AuthUser }>("/api/v1/auth/login", { method: "POST", body: JSON.stringify({ email, password }) }), remember); }, [completeLogin]);
  const signup = useCallback(async ({ fullName, email, password, confirmPassword, remember = false }: SignupCredentials) => { if (password !== confirmPassword) throw new Error("Passwords do not match."); await completeLogin(await request<TokenBundle & { user: AuthUser }>("/api/v1/auth/signup", { method: "POST", body: JSON.stringify({ full_name: fullName, email, password }) }), remember); }, [completeLogin]);
  const logout = useCallback(async () => { const existing = getStoredSession(); try { if (existing) await request("/api/v1/auth/logout", { method: "POST", body: JSON.stringify({ refresh_token: existing.refresh_token }) }); } finally { clearStoredSession(); setUser(null); } }, []);
  const forgotPassword = useCallback(async (email: string) => (await request<{ message: string }>("/api/v1/auth/forgot-password", { method: "POST", body: JSON.stringify({ email }) })).message, []);
  const value = useMemo(() => ({ user, loading, isAuthenticated: Boolean(user), login, signup, logout, refreshSession, forgotPassword }), [user, loading, login, signup, logout, refreshSession, forgotPassword]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useCareerAuth() { const context = useContext(AuthContext); if (!context) throw new Error("useCareerAuth must be used within AuthProvider"); return context; }
