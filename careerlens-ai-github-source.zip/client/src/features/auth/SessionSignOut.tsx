import { LogOut } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useCareerAuth } from "./AuthProvider";

export function SessionSignOut({ onSignedOut }: { onSignedOut: () => void }) {
  const { isAuthenticated, logout } = useCareerAuth();
  const [pending, setPending] = useState(false);
  if (!isAuthenticated) return null;
  return <button onClick={async () => { setPending(true); try { await logout(); toast.success("Signed out securely."); onSignedOut(); } catch { toast.error("Your local session was cleared. Please sign in again."); onSignedOut(); } finally { setPending(false); } }} disabled={pending} className="fixed bottom-5 right-5 z-50 inline-flex items-center gap-2 rounded-xl bg-indigo-950 px-4 py-3 text-xs font-extrabold text-white shadow-xl transition hover:bg-indigo-900 disabled:opacity-60"><LogOut size={15}/>{pending ? "Signing out…" : "Sign out"}</button>;
}
