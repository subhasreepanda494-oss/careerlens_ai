import { describe, expect, it } from "vitest";
import { calculateMatch, calculateProgress, filterAndSortRecommendations, validateResumeFile } from "./model";

describe("CareerLens workspace helpers", () => {
  it("validates a supported resume file and rejects oversized or unsupported uploads", () => {
    expect(validateResumeFile({ name: "resume.pdf", type: "application/pdf", size: 2_000_000 })).toBeNull();
    expect(validateResumeFile({ name: "resume.txt", type: "text/plain", size: 1_000 })).toBe("Choose a PDF or DOCX resume.");
    expect(validateResumeFile({ name: "resume.docx", type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document", size: 11 * 1024 * 1024 })).toBe("Choose a file smaller than 10 MB.");
  });

  it("calculates explainable progress and match values", () => {
    expect(calculateProgress(3, 6)).toBe(50);
    expect(calculateProgress(0, 0)).toBe(0);
    expect(calculateMatch(4, 5)).toBe(80);
  });
});


describe("recommendation filters", () => {
  it("matches any selected skill and filters by deadline", () => {
    const records = [
      { id: "a", location: "Bengaluru", salaryMax: 9, requirements: ["SQL", "Python"], match: 80, deadlineDays: 5 },
      { id: "b", location: "Mumbai", salaryMax: 11, requirements: ["SQL", "Product metrics"], match: 60, deadlineDays: 21 },
      { id: "c", location: "Remote", salaryMax: 6, requirements: ["Excel"], match: 70, deadlineDays: 10 },
    ];
    const filtered = filterAndSortRecommendations(records, { location: "any", salaryBand: "any", requiredSkills: ["Python", "Excel"], deadlineWindow: "14", sortBy: "best-match" });
    expect(filtered.map((item) => item.id)).toEqual(["a", "c"]);
  });

  it("supports salary and deadline sorting", () => {
    const records = [
      { id: "a", location: "Bengaluru", salaryMax: 9, requirements: ["SQL"], match: 80, deadlineDays: 12 },
      { id: "b", location: "Mumbai", salaryMax: 11, requirements: ["SQL"], match: 60, deadlineDays: 4 },
    ];
    expect(filterAndSortRecommendations(records, { location: "any", salaryBand: "any", requiredSkills: [], deadlineWindow: "any", sortBy: "salary-high" }).map((item) => item.id)).toEqual(["b", "a"]);
    expect(filterAndSortRecommendations(records, { location: "any", salaryBand: "any", requiredSkills: [], deadlineWindow: "any", sortBy: "deadline" }).map((item) => item.id)).toEqual(["b", "a"]);
  });
});
