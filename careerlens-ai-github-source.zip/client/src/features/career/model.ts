export type EvidenceKind = "user" | "resume" | "source" | "ai" | "demo";

export const ACCEPTED_RESUME_TYPES = [
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
] as const;

export function validateResumeFile(file: Pick<File, "name" | "size" | "type">) {
  const extensionIsAllowed = /\.(pdf|docx)$/i.test(file.name);
  const typeIsAllowed = ACCEPTED_RESUME_TYPES.includes(file.type as (typeof ACCEPTED_RESUME_TYPES)[number]);
  if (!extensionIsAllowed && !typeIsAllowed) return "Choose a PDF or DOCX resume.";
  if (file.size > 10 * 1024 * 1024) return "Choose a file smaller than 10 MB.";
  return null;
}

export function calculateProgress(completed: number, total: number) {
  if (total <= 0) return 0;
  return Math.round((completed / total) * 100);
}

export function calculateMatch(matchedSkills: number, requiredSkills: number) {
  if (requiredSkills <= 0) return 0;
  return Math.round((matchedSkills / requiredSkills) * 100);
}

export type RecommendationRecord = {
  id: string;
  location: string;
  salaryMax: number;
  requirements: string[];
  match: number;
  deadlineDays: number;
};

export type RecommendationFilters = {
  location: string;
  salaryBand: "any" | "under-7" | "7-to-9" | "over-9";
  requiredSkills: string[];
  deadlineWindow: "any" | "7" | "14" | "30";
  sortBy: "best-match" | "salary-high" | "location" | "deadline";
};

export function filterAndSortRecommendations(records: RecommendationRecord[], filters: RecommendationFilters) {
  const filtered = records.filter((record) => {
    const locationMatches = filters.location === "any" || record.location === filters.location;
    const skillMatches = filters.requiredSkills.length === 0 || filters.requiredSkills.some((skill) => record.requirements.includes(skill));
    const salaryMatches = filters.salaryBand === "any"
      || (filters.salaryBand === "under-7" && record.salaryMax < 7)
      || (filters.salaryBand === "7-to-9" && record.salaryMax >= 7 && record.salaryMax <= 9)
      || (filters.salaryBand === "over-9" && record.salaryMax > 9);
    const deadlineMatches = filters.deadlineWindow === "any" || record.deadlineDays <= Number(filters.deadlineWindow);
    return locationMatches && skillMatches && salaryMatches && deadlineMatches;
  });

  return [...filtered].sort((left, right) => {
    if (filters.sortBy === "salary-high") return right.salaryMax - left.salaryMax || right.match - left.match;
    if (filters.sortBy === "location") return left.location.localeCompare(right.location) || right.match - left.match;
    if (filters.sortBy === "deadline") return left.deadlineDays - right.deadlineDays || right.match - left.match;
    return right.match - left.match || right.salaryMax - left.salaryMax;
  });
}
