import { describe, expect, it } from "vitest";
import { createResumeExtractionOutcome, extractResume, extractResumeText } from "./resumeExtraction";

const PDF_FIXTURE = "JVBERi0xLjMKMyAwIG9iago8PC9UeXBlIC9QYWdlCi9QYXJlbnQgMSAwIFIKL1Jlc291cmNlcyAyIDAgUgovQ29udGVudHMgNCAwIFI+PgplbmRvYmoKNCAwIG9iago8PC9GaWx0ZXIgL0ZsYXRlRGVjb2RlIC9MZW5ndGggMjEzPj4Kc3RyZWFtCnicbY5BTsMwEEX3PcVfghSZODRy210jggRiURRfYNq4ZMDYle3QltNjoiIhwW5m9N+bX+FxVopa4ThrNG7uJeRclCX0Hq3+Pt1KIZdQy1pIBd3jat1zYnQDhXe6hn695CZU/oeq7K8n9I4SYe3InmP6hV5ycyUWiynXvbG1cYXNOQ3eFeienwps/NEENA95ItdTLNCedsb+9VS1qMrJ054OJrBxO7NCM7JNyNyw9RT6iCzJay70wXEky5+U2LuIvQ/YjpGdiRHBHHxI7F7Ez58vkXRWKwplbmRzdHJlYW0KZW5kb2JqCjEgMCBvYmoKPDwvVHlwZSAvUGFnZXMKL0tpZHMgWzMgMCBSIF0KL0NvdW50IDEKL01lZGlhQm94IFswIDAgNTk1LjI4IDg0MS44OV0KPj4KZW5kb2JqCjUgMCBvYmoKPDwvVHlwZSAvRm9udAovQmFzZUZvbnQgL0hlbHZldGljYQovU3VidHlwZSAvVHlwZTEKL0VuY29kaW5nIC9XaW5BbnNpRW5jb2RpbmcKPj4KZW5kb2JqCjIgMCBvYmoKPDwKL1Byb2NTZXQgWy9QREYgL1RleHQgL0ltYWdlQiAvSW1hZ2VDIC9JbWFnZUldCi9Gb250IDw8Ci9GMSA1IDAgUgo+PgovWE9iamVjdCA8PAo+Pgo+PgplbmRvYmoKNiAwIG9iago8PAovUHJvZHVjZXIgKFB5RlBERiAxLjcuMiBodHRwOi8vcHlmcGRmLmdvb2dsZWNvZGUuY29tLykKL0NyZWF0aW9uRGF0ZSAoRDoyMDI2MDgyNzEyNTMzOSkKPj4KZW5kb2JqCjcgMCBvYmoKPDwKL1R5cGUgL0NhdGFsb2cKL1BhZ2VzIDEgMCBSCi9PcGVuQWN0aW9uIFszIDAgUiAvRml0SCBudWxsXQovUGFnZUxheW91dCAvT25lQ29sdW1uCj4+CmVuZG9iagp4cmVmCjAgOAowMDAwMDAwMDAwIDY1NTM1IGYgCjAwMDAwMDAzNzAgMDAwMDAgbiAKMDAwMDAwMDU1MyAwMDAwMCBuIAowMDAwMDAwMDA5IDAwMDAwIG4gCjAwMDAwMDAwODcgMDAwMDAgbiAKMDAwMDAwMDQ1NyAwMDAwMCBuIAowMDAwMDAwNjU3IDAwMDAwIG4gCjAwMDAwMDA3NjYgMDAwMDAgbiAKdHJhaWxlcgo8PAovU2l6ZSA4Ci9Sb290IDcgMCBSCi9JbmZvIDYgMCBSCj4+CnN0YXJ0eHJlZgo4NjkKJSVFT0YK";
const DOCX_FIXTURE = "UEsDBBQAAAAIADBnG115bjPX6AAAAK0BAAATAAAAW0NvbnRlbnRfVHlwZXNdLnhtbH1QyU7DMBD9FWuuKHHggBCK0wPLETiUDxjZk8SqN3nc0v49Tlt6QIXjzFv1+tXeO7GjzDYGBbdtB4KCjsaGScHn+rV5AMEFg0EXAyk4EMNq6NeHRCyqNrCCuZT0KCXrmTxyGxOFiowxeyz1zJNMqDc4kbzrunupYygUSlMWDxj6Zxpx64p42df3qUcmxyCeTsQlSwGm5KzGUnG5C+ZXSnNOaKvyyOHZJr6pBJBXExbk74Cz7r0Ok60h8YG5vKGvLPkVs5Em6q2vyvZ/mys94zhaTRf94pZy1MRcF/euvSAebfjpL49zD99QSwMEFAAAAAgAMGcbXZv9N+qtAAAAKQEAAAsAAABfcmVscy8ucmVsc43POw7CMAwG4KtE3mlaBoRQ0y4IqSsqB7ASN61oHkrCo7cnAwNFDIy2f3+W6/ZpZnanECdnBVRFCYysdGqyWsClP232wGJCq3B2lgQsFKFt6jPNmPJKHCcfWTZsFDCm5A+cRzmSwVg4TzZPBhcMplwGzT3KK2ri27Lc8fBpwNpknRIQOlUB6xdP/9huGCZJRydvhmz6ceIrkWUMmpKAhwuKq3e7yCzwpuarF5sXUEsDBBQAAAAIADBnG10B9A0T6AAAAHUBAAARAAAAd29yZC9kb2N1bWVudC54bWyFUMFOwzAM/RUr59IUDghVbScOcAIBGnxAlpg1WhJHcUbXvyeZQEgIicuzbD8/+3nYnLyDD0xsKYzisu0EYNBkbNiP4u31/uJGAGcVjHIUcBQrsthMw9Ib0kePIUMRCNwvo5hzjr2UrGf0iluKGErvnZJXuaRpLxdKJibSyFz0vZNXXXctvbJBVMkdmbXGWCFVyNMjYlLwrDK6QdZCxXTG+Jv7FAs3FyMMt0G5lfO/I9uDdY57uDtpdA1sXx6aaveAMzmDCTR5fwxWn2Ub+DoevIqxOGjAKJ53pFL9V/vHNvntSv58bPoEUEsBAhQDFAAAAAgAMGcbXXluM9foAAAArQEAABMAAAAAAAAAAAAAAIABAAAAAFtDb250ZW50X1R5cGVzXS54bWxQSwECFAMUAAAACAAwZxtdm/036q0AAAApAQAACwAAAAAAAAAAAAAAgAEZAQAAX3JlbHMvLnJlbHNQSwECFAMUAAAACAAwZxtdAfQNE+gAAAB1AQAAEQAAAAAAAAAAAAAAgAHvAQAAd29yZC9kb2N1bWVudC54bWxQSwUGAAAAAAMAAwC5AAAABgMAAAAA";
const EMPTY_PDF_FIXTURE = "JVBERi0xLjMKMyAwIG9iago8PC9UeXBlIC9QYWdlCi9QYXJlbnQgMSAwIFIKL1Jlc291cmNlcyAyIDAgUgovQ29udGVudHMgNCAwIFI+PgplbmRvYmoKNCAwIG9iago8PC9GaWx0ZXIgL0ZsYXRlRGVjb2RlIC9MZW5ndGggMTk+PgpzdHJlYW0KeJwzUvDiMtAzNVco5wIAC/wCEgplbmRzdHJlYW0KZW5kb2JqCjEgMCBvYmoKPDwvVHlwZSAvUGFnZXMKL0tpZHMgWzMgMCBSIF0KL0NvdW50IDEKL01lZGlhQm94IFswIDAgNTk1LjI4IDg0MS44OV0KPj4KZW5kb2JqCjIgMCBvYmoKPDwKL1Byb2NTZXQgWy9QREYgL1RleHQgL0ltYWdlQiAvSW1hZ2VDIC9JbWFnZUldCi9Gb250IDw8Cj4+Ci9YT2JqZWN0IDw8Cj4+Cj4+CmVuZG9iago1IDAgb2JqCjw8Ci9Qcm9kdWNlciAoUHlGUERGIDEuNy4yIGh0dHA6Ly9weWZwZGYuZ29vZ2xlY29kZS5jb20vKQovQ3JlYXRpb25EYXRlIChEOjIwMjYwODI3MTMwMzQzKQo+PgplbmRvYmoKNiAwIG9iago8PAovVHlwZSAvQ2F0YWxvZwovUGFnZXMgMSAwIFIKL09wZW5BY3Rpb24gWzMgMCBSIC9GaXRIIG51bGxdCi9QYWdlTGF5b3V0IC9PbmVDb2x1bW4KPj4KZW5kb2JqCnhyZWYKMCA3CjAwMDAwMDAwMDAgNjU1MzUgZiAKMDAwMDAwMDE3NSAwMDAwMCBuIAowMDAwMDAwMjYyIDAwMDAwIG4gCjAwMDAwMDAwMDkgMDAwMDAgbiAKMDAwMDAwMDA4NyAwMDAwIG4gCjAwMDAwMDM1NiAwMDAwMCBuIAowMDAwMDAwNDY1IDAwMDAwIG4gCnRyYWlsZXIKPDwKL1NpemUgNwovUm9vdCA2IDAgUgovSW5mbyA1IDAgUgo+PgpzdGFydHhyZWYKNWNjOQolJUVPRgo=";

describe("resume extraction", () => {
  it("parses a valid PDF and returns its detected skills", async () => {
    const file = new File([Buffer.from(PDF_FIXTURE, "base64")], "resume.pdf", { type: "application/pdf" });
    const text = await extractResumeText(file);
    const outcome = createResumeExtractionOutcome(text);
    expect(outcome.hasSelectableText).toBe(true);
    expect(outcome.skills).toEqual(expect.arrayContaining(["Python", "SQL", "Power BI", "Pandas", "Excel"]));
  });

  it("parses a valid DOCX and returns its detected skills", async () => {
    const file = new File([Buffer.from(DOCX_FIXTURE, "base64")], "resume.docx", { type: "application/vnd.openxmlformats-officedocument.wordprocessingml.document" });
    const text = await extractResumeText(file);
    const outcome = createResumeExtractionOutcome(text);
    expect(outcome.hasSelectableText).toBe(true);
    expect(outcome.skills).toEqual(expect.arrayContaining(["SQL", "Excel", "Stakeholder communication", "Process mapping", "Dashboarding"]));
  });

  it("keeps empty or image-only extraction distinct from an unreadable file", async () => {
    const file = new File([Buffer.from(EMPTY_PDF_FIXTURE, "base64")], "empty-resume.pdf", { type: "application/pdf" });
    const outcome = await extractResume(file);
    expect(outcome.hasSelectableText).toBe(false);
    expect(outcome.skills).toEqual([]);
    expect(createResumeExtractionOutcome("   ").hasSelectableText).toBe(false);
  });

  it("reads the plain-text fallback and rejects malformed PDF bytes", async () => {
    const textFile = new File(["Python and SQL"], "resume.txt", { type: "text/plain" });
    await expect(extractResumeText(textFile)).resolves.toContain("Python");

    const malformedPdf = new File(["not a real PDF"], "resume.pdf", { type: "application/pdf" });
    await expect(extractResumeText(malformedPdf)).rejects.toBeTruthy();
  });
});
