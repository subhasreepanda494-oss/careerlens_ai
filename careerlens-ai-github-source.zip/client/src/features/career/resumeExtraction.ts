import pdfWorkerUrl from "pdfjs-dist/build/pdf.worker.min.mjs?url";

export const skillDictionary = [
  "SQL", "Python", "Excel", "Power BI", "Pandas", "Data visualization",
  "Business communication", "Stakeholder communication", "Process mapping",
  "Dashboarding", "Product metrics", "Experiment design", "Data storytelling",
] as const;

export type ResumeExtractionOutcome = {
  text: string;
  skills: string[];
  hasSelectableText: boolean;
};

export function detectResumeSkills(text: string) {
  const normalized = text.toLowerCase();
  return skillDictionary.filter((skill) => normalized.includes(skill.toLowerCase()));
}

export function createResumeExtractionOutcome(text: string): ResumeExtractionOutcome {
  const normalizedText = text.trim();
  return {
    text: normalizedText,
    skills: detectResumeSkills(normalizedText),
    hasSelectableText: normalizedText.length > 0,
  };
}

export async function extractResume(file: File): Promise<ResumeExtractionOutcome> {
  return createResumeExtractionOutcome(await extractResumeText(file));
}

export async function extractResumeText(file: File) {
  if (file.type === "application/pdf" || /\.pdf$/i.test(file.name)) {
    const pdfjs = await import("pdfjs-dist/legacy/build/pdf.mjs");
    let workerSrc = pdfWorkerUrl;
    if (typeof window === "undefined") {
      const { createRequire } = await import("node:module");
      const { pathToFileURL } = await import("node:url");
      const workerPath = createRequire(import.meta.url).resolve("pdfjs-dist/legacy/build/pdf.worker.mjs");
      workerSrc = pathToFileURL(workerPath).href;
    }
    pdfjs.GlobalWorkerOptions.workerSrc = workerSrc;
    const data = await file.arrayBuffer();
    const loadingOptions = { data };
    const document = await pdfjs.getDocument(loadingOptions).promise;
    const pages: string[] = [];
    for (let pageNumber = 1; pageNumber <= document.numPages; pageNumber += 1) {
      const page = await document.getPage(pageNumber);
      const content = await page.getTextContent();
      pages.push(content.items.map((item) => "str" in item ? item.str : "").join(" "));
    }
    return pages.join(" ");
  }

  if (file.type.includes("wordprocessingml") || /\.docx$/i.test(file.name)) {
    const mammoth = await import("mammoth/mammoth.browser");
    const result = await mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() });
    return result.value;
  }

  return file.text();
}
